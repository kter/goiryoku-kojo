# Shared utilities for Cloud Functions
